/**
* 
*/
package TestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import Pages.LoginPage;

/**
* @author Mukesh_50
*
*/
public class VerifyWordpressLogin 
{


@Test
public void verifyValidLogin()
{
	
	System.setProperty("webdriver.chrome.driver","C:\\Hybrid Keyword Driven\\chromedriver.exe");
	  ChromeOptions ops = new ChromeOptions();
	  ops.addArguments("--disable-notifications");
	  WebDriver driver = new ChromeDriver(ops);

driver.get("http://demosite.center/wordpress/wp-login.php");

LoginPage login=new LoginPage(driver);


login.loginToWordpress("lokesh","fkasdfl; sd");
//login.clickOnLoginButton();


driver.quit();

}


}