package TestCases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.AnalysisStrategy;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import Pages.BasePage;
import Reporting.ExtentManager;
import Utility.GetScreenshot;
import Utility.Email;

public class BasePageTest extends Base.TestBaseSetup{
	
	ExtentReports extent;
	ExtentTest test;
	WebDriver driver;
	BasePage basePage = new BasePage(driver);
	
	@BeforeClass
	public void setUp() {
		extent = ExtentManager.GetExtent();
		driver=getDriver();
		extent.setAnalysisStrategy(AnalysisStrategy.TEST);
	}
	
	@Test
	
	public void Verify_Account_Creation() throws Exception {
		
		test = extent.createTest("Account Verification", "Verify Account is valid");
		System.out.println("Home page test...");
		test.info("Creating Test Account");
		Assert.assertTrue(basePage.verifyBasePageTitle(), "YouTube");
		test.pass("Test Passed");
		
	}
	
	@Test
	public void Verify_Contact_Creation() throws Exception{
		test = extent.createTest("No Account Found");
		test.info("Creating Test Contact");
		//Assert.assertTrue(basePage.verifyBasePageTitle(), "YouTube Video Search");
	//	test.pass("Test Passed");
	//	GetScreenshot.capture(driver, "TestCase1");
		
	}
	

	@AfterMethod
	
	public void tearDown(ITestResult result) throws Exception
	{
		String screenshot_path=GetScreenshot.capture(driver, result.getName());
		if(result.getStatus()==ITestResult.FAILURE)
		{
			test.info("Test Contact not created");	
			//test.log(Status.FAIL,GetScreenshot.capture(driver,screenshot_path));
			MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromPath(screenshot_path).build();
			test.fail("Actual Result is not equal to Expected Result ", mediaModel);	
		}else if(result.getStatus()==ITestResult.SUCCESS)
		{
		///	test.log(Status.PASS, screenshot_path);
			test.info("Test Contact Created");	
			MediaEntityModelProvider mediaModel = MediaEntityBuilder.createScreenCaptureFromPath(screenshot_path).build();
			test.pass("As Expected", mediaModel);	
		}
		
		
	}
	
	@AfterSuite
	public void tear() throws Exception
	{
		extent.flush();
		driver.get("E:/Selenium/POM/extentreport.html");
		Thread.sleep(2000);
		Email.sendEmailAttachmaent();
	  /*  Robot r = new Robot();                          
	    r.keyPress(KeyEvent.VK_CONTROL); 
	    r.keyPress(KeyEvent.VK_T); 
	    r.keyRelease(KeyEvent.VK_CONTROL); 
	    r.keyRelease(KeyEvent.VK_T);

		driver.get("E:/Selenium/POM/test-output/html/index.html");*/
	}

}