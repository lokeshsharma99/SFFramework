package Utility;

import java.io.File;

import javax.imageio.ImageIO;

import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class GetScreenshot {
	
	public static String capture(WebDriver driver,String ScreenshotName) throws Exception
	{	
		Screenshot screenshot =new AShot().shootingStrategy(ShootingStrategies.viewportPasting(500)).takeScreenshot(driver);
		String dest="./Screenshots/"+ScreenshotName+".png";
		ImageIO.write(screenshot.getImage(), "PNG", new File(dest));
		return dest;		
	}

}
